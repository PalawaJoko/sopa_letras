#ifndef DEFINEDSTRUCTS_H
#define DEFINEDSTRUCTS_H

//clase que define las estructuras mas utilizadas en el programa
struct string{
    char dato[60];
};

struct casilla{
    char dato[60];
    bool ocupado;
};

#endif