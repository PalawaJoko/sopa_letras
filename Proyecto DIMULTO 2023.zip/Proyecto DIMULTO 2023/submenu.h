#ifndef SUBMENU_H
#define SUBMENU_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "modulomatriz.h"

int menuTemas(char datos[][1]);
void menuDif(char datos[][1]);
int subMenu();

#endif